This section describes how the pipeline-orchestrated WVD deployment is intended and how the possible options differ based on the implemented identity solution.

![wvddeployment.png](/.attachments/wvddeployment-892c4880-cf55-405e-bef0-b6078fe8701c.png)