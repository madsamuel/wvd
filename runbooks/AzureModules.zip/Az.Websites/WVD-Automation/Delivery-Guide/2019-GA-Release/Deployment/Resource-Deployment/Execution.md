Now, based on the customer's identity solution, the way we put the pipeline into action differs a bit:
- [Deployment with Native AD](/Delivery-Guide/Resource-Deployment/Execution/Native-AD)
- [Deployment with Azure ADDS](/Delivery-Guide/Resource-Deployment/Execution/Azure-ADDS)
