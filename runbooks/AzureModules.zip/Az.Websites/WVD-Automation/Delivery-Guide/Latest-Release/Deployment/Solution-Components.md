
As part of the solution we offer numerous features to be deployed independently. Depending on the life-cycle of the corresponding services, they are deployed into different resource groups as described in the following sub-sections.

- [General Management](/Delivery-Guide/Latest-Release/Deployment/Solution-Components/General-Management)
- [WVD Host Pool](/Delivery-Guide/Latest-Release/Deployment/Solution-Components/WVD-Host%2DPool)
- [Imaging](/Delivery-Guide/Latest-Release/Deployment/Solution-Components/Imaging)
- [FSLogix Profiles & Backup](/Delivery-Guide/Latest-Release/Deployment/Solution-Components/FSLogix-Profiles-&-Backup)
- [WVD Autoscaling](/Delivery-Guide/Latest-Release/Deployment/Solution-Components/WVD-Autoscaling)